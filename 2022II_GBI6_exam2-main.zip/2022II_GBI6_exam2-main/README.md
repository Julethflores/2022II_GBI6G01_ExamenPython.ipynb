# 2022II_GBI6_exam2
Examen de Bioinformática, módulo de Python
